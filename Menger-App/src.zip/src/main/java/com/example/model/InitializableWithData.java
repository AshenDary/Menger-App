package com.example.model;

public interface InitializableWithData {
    void init(Object data);
}
